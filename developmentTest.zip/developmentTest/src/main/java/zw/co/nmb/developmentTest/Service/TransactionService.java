package zw.co.nmb.developmentTest.Service;

import org.springframework.beans.factory.annotation.Autowired;

import zw.co.nmb.developmentTest.Repository.AccountRepository;
import zw.co.nmb.developmentTest.Repository.TransactionRepository;
import zw.co.nmb.developmentTest.model.Account;
import zw.co.nmb.developmentTest.model.Transaction;

public class TransactionService {
	@Autowired
	private TransactionRepository transationRepository;
	@Autowired
	private AccountRepository accountRepository;
	
	
	public Transaction addTransaction(Transaction transation) {
		transationRepository.save(transation);
		
		Account newAccount = new Account();
		
		newAccount = accountRepository.findById(transation.getAccount().getId()).orElse(null);
		
		if(transation.isDRorCR()) {
			//TODO Check if customer credited account in the previous month add 6% if yes
			
			newAccount.setCreditAmount( transation.getAmount());
			
			newAccount.setActiveBalance((newAccount.getActiveBalance() + transation.getAmount()) );
			accountRepository.save(newAccount);
		}else {
			
			newAccount.setDebitAmount(transation.getAmount());
			newAccount.setActiveBalance((newAccount.getActiveBalance() - transation.getAmount()) -transation.getAmount() * 0.02 );
			accountRepository.save(newAccount);
		}
		
		//TODO check the previous transaction Date, add 3% if it is within 14 days in the same month
		
		return transation;
		
	}

}
