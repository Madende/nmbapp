package zw.co.nmb.Requests;

import zw.co.nmb.developmentTest.model.Customer;

public class AccountRequest {

	private String accountNumber;
	private String dateOfCreation;
	private String currency;
	private String mobileNumber;
	private double initialBalance;
	private double activeBalance;
	private double debitAmount;
	private double creditAmount;
	private double debitNarration;
	private Branch branch;
	private Customer customer;
	
	public Branch getBranch() {
		return branch;
	}
	public void setBranch(Branch branch) {
		this.branch = branch;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getDateOfCreation() {
		return dateOfCreation;
	}
	public void setDateOfCreation(String dateOfCreation) {
		this.dateOfCreation = dateOfCreation;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public double getInitialBalance() {
		return initialBalance;
	}
	public void setInitialBalance(double initialBalance) {
		this.initialBalance = initialBalance;
	}
	public double getActiveBalance() {
		return activeBalance;
	}
	public void setActiveBalance(double activeBalance) {
		this.activeBalance = activeBalance;
	}
	public double getDebitAmount() {
		return debitAmount;
	}
	public void setDebitAmount(double debitAmount) {
		this.debitAmount = debitAmount;
	}
	public double getCreditAmount() {
		return creditAmount;
	}
	public void setCreditAmount(double creditAmount) {
		this.creditAmount = creditAmount;
	}
	public double getDebitNarration() {
		return debitNarration;
	}
	public void setDebitNarration(double debitNarration) {
		this.debitNarration = debitNarration;
	}


}
