package zw.co.nmb.developmentTest.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import zw.co.nmb.developmentTest.model.Branch;

@Repository
public interface BranchRepository extends JpaRepository<Branch, Integer> {

//	@Modifying
//	Branch updateBranch(Branch branch);


}
