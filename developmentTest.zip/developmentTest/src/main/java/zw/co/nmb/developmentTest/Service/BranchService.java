package zw.co.nmb.developmentTest.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import zw.co.nmb.developmentTest.Repository.BranchRepository;
import zw.co.nmb.developmentTest.model.Branch;

@Service
public class BranchService {
	
	@Autowired
	private BranchRepository repository;
	
	public Branch addbranch(Branch branch) {
		return repository.save(branch);
	}
	
	public List<Branch> getBranches(){
		return repository.findAll();
	}

	public void deleteBranchById(int id) {
		repository.deleteById(id);
	}

//	public Branch updateBranch(Branch branch) {
//		return repository.updateBranch(branch);
//	}


}
