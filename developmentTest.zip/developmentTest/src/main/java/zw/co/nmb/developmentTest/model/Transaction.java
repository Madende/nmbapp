package zw.co.nmb.developmentTest.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "TRANSACTION")
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "date")
	private String date;
	
	//true for CR and false for DR
	@Column(name ="DR_or_CR")
	private boolean DRorCR;
	
	@ManyToOne
	@JoinColumn(name="account", nullable=false,insertable=true, updatable=false)
	private Account account;
	
	@Column(name = "amount")
	private Long amount;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public boolean isDRorCR() {
		return DRorCR;
	}

	public void setDRorCR(boolean dRorCR) {
		DRorCR = dRorCR;
	}

	public Long getAmount() {
		return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}
	
	

}
