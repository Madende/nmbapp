package zw.co.nmb.developmentTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevelopmentTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevelopmentTestApplication.class, args);
	}

}
