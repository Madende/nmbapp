package zw.co.nmb.developmentTest.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "BRANCH")
public class Branch {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "record_id")
	private int id;

	@Column(name = "branch_code", unique= true)
	private int branchCode;
	
	@Column(name = "branch_name")
	private String branchName;
	
	
	private String address;
	
	@OneToMany(mappedBy="branch", cascade=CascadeType.ALL)
	private List<Account> accounts;
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(int branchCode) {
		this.branchCode = branchCode;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	 
	

}
