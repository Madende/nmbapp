package zw.co.nmb.developmentTest.Contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import zw.co.nmb.developmentTest.Service.CustomerService;
import zw.co.nmb.developmentTest.model.Customer;

@RestController
public class CustomerController {
	
	@Autowired
	private CustomerService service;
	
	
	@PostMapping("/addcustomer")
	public Customer addbranch(@RequestBody Customer customer) {
		return service.addCustomer(customer);
	}
	
	@GetMapping("/getcustomers")
	public List<Customer> getCustomers() {
		return service.getCustomers();
	}

}
