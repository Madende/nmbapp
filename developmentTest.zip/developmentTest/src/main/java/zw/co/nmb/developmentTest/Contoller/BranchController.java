package zw.co.nmb.developmentTest.Contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import zw.co.nmb.developmentTest.Service.BranchService;
import zw.co.nmb.developmentTest.model.Branch;

@RestController
public class BranchController {
	
	@Autowired
	private BranchService service;
	
	@PostMapping("/addbranch")
	public Branch addbranch(@RequestBody Branch branch) {
		return service.addbranch(branch);
	}
	
	@GetMapping("/getbranches")
	public List<Branch> branch() {
		return service.getBranches();
	}
	
	@DeleteMapping("/deleteBranch/{id}")
	public String deleteBranch(@PathVariable("id") int id ) {
		service.deleteBranchById(id);
		return "Delete Success";
	}
	
//	@PutMapping("/updateBranch")
//	public Branch updateBranch(@RequestBody Branch branch) {
//		return service.updateBranch(branch);
//	}
	
}
