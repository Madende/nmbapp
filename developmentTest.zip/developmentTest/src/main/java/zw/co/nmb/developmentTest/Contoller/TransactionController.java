package zw.co.nmb.developmentTest.Contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import zw.co.nmb.developmentTest.Service.CustomerService;
import zw.co.nmb.developmentTest.Service.TransactionService;
import zw.co.nmb.developmentTest.model.Customer;
import zw.co.nmb.developmentTest.model.Transaction;

@RestController
public class TransactionController {
	
	@Autowired
	private TransactionService service;
	
	
	@PostMapping("/addTransaction")
	public Transaction addTransaction(@RequestBody Transaction transaction) {
		return service.addTransaction(transaction);
	}
	

}
