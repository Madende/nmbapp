package zw.co.nmb.developmentTest.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import zw.co.nmb.developmentTest.model.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Integer>{

}
