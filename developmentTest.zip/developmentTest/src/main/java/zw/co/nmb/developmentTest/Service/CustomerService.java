package zw.co.nmb.developmentTest.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import zw.co.nmb.developmentTest.Repository.CustomerRepository;
import zw.co.nmb.developmentTest.model.Customer;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository repository;

	public Customer addCustomer(Customer customer) {
		return repository.save(customer);
	}

	public List<Customer> getCustomers() {
		return repository.findAll();
	}
}
