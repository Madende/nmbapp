package zw.co.nmb.developmentTest.Contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import zw.co.nmb.Requests.AccountRequest;
import zw.co.nmb.developmentTest.Service.AccountService;
import zw.co.nmb.developmentTest.model.Account;



@RestController
public class AccountController {
	
	@Autowired
	private AccountService service;
	
	@PostMapping("/addaccount")
	public Account addAccount(@RequestBody Account account) {
		return service.addAccount(account);
	}
	
//	@GetMapping("/accounts")
//	public List<Account> getAccounts(){
//		return service.getAccounts();
//	}

}
