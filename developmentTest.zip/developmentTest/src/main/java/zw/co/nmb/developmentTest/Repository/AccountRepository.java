package zw.co.nmb.developmentTest.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import zw.co.nmb.developmentTest.model.Account;

@Repository
public interface AccountRepository extends JpaRepository<Account, Integer> {


}
