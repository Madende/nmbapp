package zw.co.nmb.developmentTest.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "ACCOUNT")
public class Account{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "record_id")
	private int id;

	@Column(name = "account_number", unique = true)
	private String accountNumber;
	@Column(name = "date_of_creation")
	private String dateOfCreation;
	private String currency;
	@Column(name = "mobile_number")
	private String mobileNumber;
	@Column(name = "initial_balance")
	private double initialBalance;
	@Column(name = "active_balance")
	private double activeBalance;
	@Column(name = "debit_amount")
	private double debitAmount;
	@Column(name = "credit_amount")
	private double creditAmount;
	@Column(name = "debit_narration")
	private double debitNarration;
	@ManyToOne
	@JoinColumn(name="branch", nullable=false,insertable=true, updatable=false)
	private Branch branch;
	
	@ManyToOne
	@JoinColumn(name="customer", nullable=false,insertable=true, updatable=true)
	private Customer customer;
	

	@OneToMany(mappedBy="account", cascade=CascadeType.ALL)
	private List<Transaction> transactions;
	

	public Customer getCustomerId() {
		return customer;
	}
	public void setCustomerId(Customer customerId) {
		this.customer = customerId;
	}
	public Branch getBranch() {
		return branch;
	}
	public void setBranch(Branch branch) {
		this.branch = branch;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getDateOfCreation() {
		return dateOfCreation;
	}
	public void setDateOfCreation(String dateOfCreation) {
		this.dateOfCreation = dateOfCreation;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public double getInitialBalance() {
		return initialBalance;
	}
	public void setInitialBalance(double initialBalance) {
		this.initialBalance = initialBalance;
	}
	public double getActiveBalance() {
		return activeBalance;
	}
	public void setActiveBalance(double activeBalance) {
		this.activeBalance = activeBalance;
	}
	public double getDebitAmount() {
		return debitAmount;
	}
	public void setDebitAmount(double debitAmount) {
		this.debitAmount = debitAmount;
	}
	public double getCreditAmount() {
		return creditAmount;
	}
	public void setCreditAmount(double creditAmount) {
		this.creditAmount = creditAmount;
	}
	public double getDebitNarration() {
		return debitNarration;
	}
	public void setDebitNarration(double debitNarration) {
		this.debitNarration = debitNarration;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public List<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	
	
	
	
	

}
