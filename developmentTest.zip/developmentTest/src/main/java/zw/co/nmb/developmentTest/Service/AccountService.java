package zw.co.nmb.developmentTest.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import zw.co.nmb.Requests.AccountRequest;
import zw.co.nmb.developmentTest.Repository.AccountRepository;
import zw.co.nmb.developmentTest.Repository.BranchRepository;
import zw.co.nmb.developmentTest.Repository.CustomerRepository;
import zw.co.nmb.developmentTest.model.Account;
import zw.co.nmb.developmentTest.model.Branch;
import zw.co.nmb.developmentTest.model.Customer;

@Service
public class AccountService {
	
	@Autowired
	private AccountRepository accountRepository;
	private BranchRepository branchRepository;
	private CustomerRepository customerRepository;
	
	private Account account;
	private Branch branch;
	private Customer customer;
	

	
	public Account addAccount(Account account) {
		return accountRepository.save(account);
	}
	
	public String deleteAccount(int account) {
		accountRepository.deleteById(account);
		return "Account Delete success";
	}
	
}
