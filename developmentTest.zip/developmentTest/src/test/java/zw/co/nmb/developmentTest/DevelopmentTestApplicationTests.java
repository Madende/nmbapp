package zw.co.nmb.developmentTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevelopmentTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
